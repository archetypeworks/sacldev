For views exposed filters add this patch:
http://drupal.org/node/1376686#comment-5481488