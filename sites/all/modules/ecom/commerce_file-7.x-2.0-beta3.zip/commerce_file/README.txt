This module extends Commerce License with the ability to sell access to files.

See https://drupal.org/node/2043917 for information on getting started.
