INTRODUCTION
------------
This module is created in order to simplify the Product Display
creation process in Commerce module by providing option the create it
at the same time with Product creation.

INSTALLATION
------------
The post-installation configuration can be done from :

http://<yoursitename>/admin/commerce/config/auto-product-display

But before that, please create at least one content type with the
product reference field.
