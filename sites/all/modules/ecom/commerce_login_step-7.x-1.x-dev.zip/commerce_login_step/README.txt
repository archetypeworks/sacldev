
--------------------------------------------------------------------------------
                         Commerce Login Step
--------------------------------------------------------------------------------

Project homepage: http://drupal.org/project/commerce_login_step


Installation:

 * Go to admin/commerce/config/checkout.
 * Make sure the Account information pane is moved to the "Customer Login" page.

This module adds a new step to the Commerce checkout process.
The user can choose if he wants to proceed as a guest or if he wants to login
with an existing account.

Under admin/commerce/config/checkout a new Checkout page appears after you
enable this module.


Troubleshooting:

If you get a "Access denied" on the first checkout page, you should redo the
steps outlined in the Installation part of this readme.
