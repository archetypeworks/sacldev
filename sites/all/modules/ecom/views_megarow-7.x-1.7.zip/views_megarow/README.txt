Views megarow is a module letting you display menu callback between two results
of a view.
The module can be used in order to preview content, build quick edit forms,
display more complex forms without having to go to a dedicated page.

Installation notes:
* Place this module in you sites/(all|<subsite>)/modules/contrib directory.
* Go to the modules page
* Enable the Views megarow module

Compatibility notes:
This module overrides by default the node/%node/edit and user/%user/edit paths
in order to provide the best experience to its users out of the box.
If you need to override those paths from your module, you can disable the
overriding behaviour from the configuration page.
